Brick Breaker
============================
Controls :
__________
* Right-Click  -> Menu
* S -> Launch Ball
* Paddle Movement :
    *Mouse
    *'A' - Left and 'R' - Right

Set the speed of the game by setting the values in the array game_level[] for different difficulties. More the value, slower the speed of the game.



Features :
__________

* Shading and Lighting
* Translation
* Raster Text
* Menu
* Keyboard Input


