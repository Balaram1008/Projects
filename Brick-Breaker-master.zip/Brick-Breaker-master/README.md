# CG Mini-Project Brick Breaker

### You Need These Files(Installations) First :
    $ sudo apt-get install freeglut3-dev
    $ sudo apt-get install libsdl1.2-dev libsdl-image1.2-dev

## To Run The File:

#### Open Terminal in Ubuntu 
Once You Downloaded The File/Repository and Extracted in Ubuntu, Launch A Terminal in The Directory of The Extracted Folder and Run These

    $ g++ filename.cpp -lGL -lGLU -lglut
    $ ./a.out

## Easier Method:

    $ git clone https://github.com/thedevilx/Brick-Breaker
    $ cd brickbreaker/BrickBreaker
    $ g++ BrickBreaker.cpp -lGL -lGLU -lglut
    $ ./a.out

* All Rights Reserved <thedevilx.github.io>
* IG: @adiiikris   (For Enquires DM)
